# Cadastro e autenticação — WhatsApp

## Recursos
- `POST /signin`: cadastro com telefone, nome e senha.
- `POST /auth`: login.
- Senhas protegidas com hash bcrypt.
- Interface simples para testar cadastro e login.

## Instalação
1. Copie `routes/signin.route.js` e `routes/auth.route.js` para a pasta `routes` do projeto.
2. Compare `db/connection.js` com a conexão que já existe antes de substituir.
3. Mescle os middlewares e imports de `main-exemplo.js` no seu `main.js`. Preserve as rotas de chat.
4. No terminal, instale: `npm install express cors mysql2 bcryptjs dotenv`
5. Execute `database.sql` no MySQL Workbench ou phpMyAdmin.
6. Configure as variáveis de conexão no arquivo `.env` usando `.env.example` como modelo.
7. Inicie a API: `node main.js`
8. Abra `frontend/index.html` pelo Live Server.

A interface em `frontend` é uma página de teste independente. Você pode usá-la para validar a API ou transferir os campos para a interface existente.
