const express = require('express');
const cors = require('cors');
const signinRoute = require('./routes/signin.route');
const authRoute = require('./routes/auth.route');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(signinRoute);
app.use(authRoute);

// Preserve e registre aqui as rotas de chat já existentes.
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`API online em http://localhost:${port}`));
