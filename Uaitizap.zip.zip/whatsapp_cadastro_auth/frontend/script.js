const API_URL = 'http://localhost:3000';
const formCadastro = document.getElementById('formCadastro');
const formLogin = document.getElementById('formLogin');
const resultado = document.getElementById('resultado');

function mostrarMensagem(texto, sucesso) {
  resultado.textContent = texto;
  resultado.style.color = sucesso ? '#087f6b' : '#c62828';
}

formCadastro.addEventListener('submit', async (event) => {
  event.preventDefault();
  const dados = {
    nome: document.getElementById('nome').value.trim(),
    telefone: document.getElementById('telefoneCadastro').value.trim(),
    senha: document.getElementById('senhaCadastro').value
  };

  try {
    const resposta = await fetch(`${API_URL}/signin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados)
    });
    const retorno = await resposta.json();
    if (!resposta.ok) throw new Error(retorno.message || 'Não foi possível cadastrar.');
    mostrarMensagem(retorno.message, true);
    formCadastro.reset();
  } catch (erro) {
    mostrarMensagem(erro.message || 'Não foi possível conectar à API.', false);
  }
});

formLogin.addEventListener('submit', async (event) => {
  event.preventDefault();
  const dados = {
    telefone: document.getElementById('telefoneLogin').value.trim(),
    senha: document.getElementById('senhaLogin').value
  };

  try {
    const resposta = await fetch(`${API_URL}/auth`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados)
    });
    const retorno = await resposta.json();
    if (!resposta.ok) throw new Error(retorno.message || 'Não foi possível entrar.');
    mostrarMensagem(`Bem-vindo(a), ${retorno.usuario.nome}! ${retorno.message}`, true);
    formLogin.reset();
  } catch (erro) {
    mostrarMensagem(erro.message || 'Não foi possível conectar à API.', false);
  }
});
