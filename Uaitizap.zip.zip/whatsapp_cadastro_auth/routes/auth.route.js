const { Router } = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db/connection');
const router = Router();

router.post('/auth', async (req, res) => {
  try {
    const { telefone, senha } = req.body;
    if (!telefone || !senha) {
      return res.status(400).json({ message: 'Informe telefone e senha.' });
    }

    const [usuarios] = await db.execute(
      'SELECT id, telefone, nome, senha FROM usuarios WHERE telefone = ?',
      [String(telefone).trim()]
    );
    if (!usuarios.length) {
      return res.status(401).json({ message: 'Telefone ou senha incorretos.' });
    }

    const usuario = usuarios[0];
    const senhaCorreta = await bcrypt.compare(String(senha), usuario.senha);
    if (!senhaCorreta) {
      return res.status(401).json({ message: 'Telefone ou senha incorretos.' });
    }

    return res.json({
      message: 'Login realizado com sucesso!',
      usuario: { id: usuario.id, telefone: usuario.telefone, nome: usuario.nome }
    });
  } catch (erro) {
    console.error('Erro no login:', erro.message);
    return res.status(500).json({ message: 'Erro interno ao autenticar usuário.' });
  }
});

module.exports = router;
