const { Router } = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db/connection');
const router = Router();

router.post('/signin', async (req, res) => {
  try {
    const { telefone, nome, senha } = req.body;
    if (!telefone || !nome || !senha) {
      return res.status(400).json({ message: 'Informe telefone, nome e senha.' });
    }

    const tel = String(telefone).trim();
    const nomeLimpo = String(nome).trim();
    if (tel.length < 8 || nomeLimpo.length < 2 || String(senha).length < 6) {
      return res.status(400).json({ message: 'Confira os dados. A senha precisa ter pelo menos 6 caracteres.' });
    }

    const [existentes] = await db.execute('SELECT id FROM usuarios WHERE telefone = ?', [tel]);
    if (existentes.length) {
      return res.status(409).json({ message: 'Já existe uma conta com esse telefone.' });
    }

    const senhaHash = await bcrypt.hash(String(senha), 10);
    await db.execute(
      'INSERT INTO usuarios (telefone, nome, senha) VALUES (?, ?, ?)',
      [tel, nomeLimpo, senhaHash]
    );

    return res.status(201).json({ message: 'Conta criada com sucesso!' });
  }catch (erro) {
    console.error('ERRO REAL DO CADASTRO:', erro);

    res.status(500).json({
        message: 'Erro interno ao cadastrar usuário.',
        erro: erro.message
    });
}
});

module.exports = router;
